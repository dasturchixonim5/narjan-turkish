# Narjan Turkish — Android ilova (v2.0)

Learn Turkish. Think Turkish. Speak Turkish.

Bu loyiha Narjan Turkish veb-platformasini (app/src/main/assets/index.html) Android ilova sifatida o'raydi:
- Android 8.0+ (minSdk 26)
- Turkcha ovoz: Android TextToSpeech (telefonda turkcha ovoz o'rnatilgan bo'lishi kerak)
- Mikrofon: Android SpeechRecognizer (tr-TR)
- AI: Sozlamalar → AI provayder → Groq (bepul, gsk_...) yoki Grok (xAI) kaliti. Kalitni hech qachon GitHub fayllariga yozmang!
- Progress telefon xotirasida saqlanadi; Sozlamalar → Zaxira nusxasi orqali ko'chiriladi

## APK'ni GitHub'da yig'ish (kompyutersiz)
1. github.com da yangi repozitoriy oching (masalan, `narjan-turkish`).
2. "uploading an existing file" orqali shu papkadagi barcha fayl va papkalarni yuklang (`.github` papkasi ham!).
3. Actions bo'limida "APK yig'ish" ishga tushadi (5–10 daqiqa).
4. Tugagach, ish sahifasidagi Artifacts → `NarjanTurkish-apk` ni yuklab oling, zip ichidagi `app-release.apk` ni telefonga o'rnating.

## Android Studio'da
File → Open → shu papka → Build → Build APK(s).

## Yangilash
Veb-versiya o'zgarsa, faqat `app/src/main/assets/index.html` faylini almashtiring va `versionCode` ni oshiring.

## v2.0 yangiliklari
- Yangi logo (brand/logo.svg, brand/logo-full.svg) va adaptive ikonka (monochrome qatlam bilan — Android 13 mavzuli ikonkalar).
- Konsepsiya dizayni: navy–binafsha gradientlar, progress halqalari, Light/Dark rejim, shrift kattaligi.
- TYS va TÖMER alohida bo'limlar; morfologiya, talaffuz, diktant, Real Turkish, akademik turkcha modullari.
- PDF kitob import (pdf.js ichida, oflayn), skan sahifalar uchun AI OCR, lug'at import (.txt/.csv).
- Talaffuz laboratoriyasida ovoz yozish uchun WebView mikrofon ruxsati.
